<?php

$db = mysqli_connect("localhost", "root", "", "craft");

if(!$db)
{
    die("connection failed:" . mysqli_connect_error());
}

?>