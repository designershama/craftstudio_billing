-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2023 at 04:22 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `craft`
--

-- --------------------------------------------------------

--
-- Table structure for table `spark_invoice`
--

CREATE TABLE `spark_invoice` (
  `invoiceno` int(11) NOT NULL,
  `date` date NOT NULL,
  `address` varchar(200) NOT NULL,
  `descslno` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `qty` varchar(200) DEFAULT NULL,
  `amount` varchar(200) DEFAULT NULL,
  `descslno1` varchar(200) DEFAULT NULL,
  `description1` varchar(200) DEFAULT NULL,
  `qty1` varchar(200) DEFAULT NULL,
  `amount1` varchar(200) DEFAULT NULL,
  `descslno2` varchar(200) DEFAULT NULL,
  `description2` varchar(200) DEFAULT NULL,
  `qty2` varchar(200) DEFAULT NULL,
  `amount2` varchar(200) DEFAULT NULL,
  `descslno3` varchar(200) DEFAULT NULL,
  `description3` varchar(200) DEFAULT NULL,
  `qty3` varchar(200) DEFAULT NULL,
  `amount3` varchar(200) DEFAULT NULL,
  `upload` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `spark_quotation`
--

CREATE TABLE `spark_quotation` (
  `quotationno` int(11) NOT NULL,
  `date` date NOT NULL,
  `descslno` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `qty` varchar(200) DEFAULT NULL,
  `amount` varchar(200) DEFAULT NULL,
  `descslno1` varchar(200) DEFAULT NULL,
  `description1` varchar(200) DEFAULT NULL,
  `qty1` varchar(200) DEFAULT NULL,
  `amount1` varchar(200) DEFAULT NULL,
  `descslno2` varchar(200) DEFAULT NULL,
  `description2` varchar(200) DEFAULT NULL,
  `qty2` varchar(200) DEFAULT NULL,
  `amount2` varchar(200) DEFAULT NULL,
  `descslno3` varchar(200) DEFAULT NULL,
  `description3` varchar(200) DEFAULT NULL,
  `qty3` varchar(200) DEFAULT NULL,
  `amount3` varchar(200) DEFAULT NULL,
  `grandtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `spark_receipt`
--

CREATE TABLE `spark_receipt` (
  `receipt_no` int(11) NOT NULL,
  `issued_date` date DEFAULT NULL,
  `client_name` varchar(200) DEFAULT NULL,
  `drawn_date` varchar(100) DEFAULT NULL,
  `payment_mode` varchar(100) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `payment` bigint(20) DEFAULT NULL,
  `balance` bigint(20) NOT NULL,
  `upload` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `email`, `password`, `date`) VALUES
(1, '6899', 'Admin', 'Admin123@gmail.com', 'Admin@123', '2022-01-08 06:03:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `spark_invoice`
--
ALTER TABLE `spark_invoice`
  ADD PRIMARY KEY (`invoiceno`);

--
-- Indexes for table `spark_quotation`
--
ALTER TABLE `spark_quotation`
  ADD PRIMARY KEY (`quotationno`);

--
-- Indexes for table `spark_receipt`
--
ALTER TABLE `spark_receipt`
  ADD PRIMARY KEY (`receipt_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `spark_invoice`
--
ALTER TABLE `spark_invoice`
  MODIFY `invoiceno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `spark_receipt`
--
ALTER TABLE `spark_receipt`
  MODIFY `receipt_no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
